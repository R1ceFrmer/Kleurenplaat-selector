const canvas = document.getElementById('myCanvas');
const ctx = canvas.getContext('2d');


function drawShape(color, shape) {
    ctx.fillStyle = color; 
    ctx.clearRect(0, 0, canvas.width, canvas.height); 

    switch (shape) {
        case 'rechthoek':
            ctx.fillRect(50, 50, 200, 100); 
            break;
        case 'cirkel':
            ctx.beginPath();
            ctx.arc(150, 200, 50, 0, Math.PI * 2); 
            ctx.fill(); 
            break;
        case 'driehoek':
            ctx.beginPath();
            ctx.moveTo(150, 150); 
            ctx.lineTo(200, 250); 
            ctx.lineTo(100, 250); 
            ctx.closePath();
            ctx.fill(); 
            break;
        default:
            alert('Onbekende vorm.');
    }
}


let kleurNummer = prompt('Voer een nummer in (1-5) voor de kleur:');
let kleur;

switch (kleurNummer) {
    case '1':
        kleur = 'red';
        break;
    case '2':
        kleur = 'green'; 
        break;
    case '3':
        kleur = 'blue'; 
        break;
    case '4':
        kleur = 'yellow'; 
        break;
    case '5':
        kleur = 'purple'; 
        break;
    default:
        alert('Ongeldig nummer, gebruik 1 t/m 5.');
        kleur = null; 
}

if (kleur) { 
    let vorm = prompt('Welke vorm wilt u tekenen? (rechthoek, cirkel, driehoek)');

    if (vorm) {
        drawShape(kleur, vorm);
    } else {
        alert('Geen vorm geselecteerd.');
    }
}
